console.log("let's go");
window.view.showApp();
$("body > section > section > div").focus();

